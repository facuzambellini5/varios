package com.todocodeacademy.estudiante_programacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstudianteProgramacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstudianteProgramacionApplication.class, args);
	}

}
