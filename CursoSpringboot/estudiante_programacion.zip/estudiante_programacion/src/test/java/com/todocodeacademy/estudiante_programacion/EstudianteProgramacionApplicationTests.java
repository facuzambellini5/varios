package com.todocodeacademy.estudiante_programacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudianteProgramacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
