package com.ejerciciopractico.cursosprogramacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursosprogramacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursosprogramacionApplication.class, args);
	}

}
