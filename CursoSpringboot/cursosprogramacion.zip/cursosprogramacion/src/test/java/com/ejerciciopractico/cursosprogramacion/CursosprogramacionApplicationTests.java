package com.ejerciciopractico.cursosprogramacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursosprogramacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
