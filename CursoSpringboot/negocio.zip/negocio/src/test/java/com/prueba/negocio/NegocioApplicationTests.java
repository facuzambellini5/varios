package com.prueba.negocio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NegocioApplicationTests {

	@Test
	void contextLoads() {
	}

}
