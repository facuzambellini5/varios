package com.prueba.DTO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
