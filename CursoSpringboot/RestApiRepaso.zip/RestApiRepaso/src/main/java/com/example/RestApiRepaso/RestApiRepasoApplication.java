package com.example.RestApiRepaso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiRepasoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiRepasoApplication.class, args);
	}

}
