package com.practica.clinicaveterinaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaveterinariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
