package com.prueba.EjerciciosPracticos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciosPracticosApplicationTests {

	@Test
	void contextLoads() {
	}

}
