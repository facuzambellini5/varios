package com.prueba.posteoEjercicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PosteoEjercicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(PosteoEjercicioApplication.class, args);
	}

}
